<template>
	<div class="hello">
		<h3>111111111111111111111</h3>
		
	</div>
</template>

<script>
	import KindEditor from 'kindeditor'
	export default {
		name: 'hello',
		data() {
			return {
				msg: 'Welcome to Your Vue.js App'
			}
		}
	}
</script>

